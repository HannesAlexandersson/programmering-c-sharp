﻿using MusicLinq.Data;

JsonDatabase Database = JsonDatabase.Load();

//
// some example code!
//
// select all artists with an ArtistId less than 20, and sort them by lenght of name backwards
//
var result = Database.Artists
        .Where(artist => artist.ArtistID < 20)
        .OrderByDescending(artist => artist.Name.Length);

foreach (var artist in result)
{
    Console.WriteLine(artist.Name);
}